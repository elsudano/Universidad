/* 
 * File:   pregunta1.hxx
 * Author: usuario
 *
 * Created on 3 de noviembre de 2015, 13:06
 */

#include <string>

using namespace std;

/*********************************************************************
 *  Constructor vacío.
 ********************************************************************/
pregunta::pregunta(){
    
}

/*********************************************************************
 *  Constructor de copia.
 ********************************************************************/
pregunta::pregunta(const pregunta &P){
    
}

/*********************************************************************
 *  Constructor normal.
 ********************************************************************/
pregunta::pregunta(enunciado E, respuesta A, respuesta B, respuesta C, respuesta D, unsigned int correcta){
    
}

/*********************************************************************
 *  Devuelve el Enunciado de la Pregunta.
 ********************************************************************/
pregunta::enunciado pregunta::getEnunciado(){
    
}

/*********************************************************************
 *  Devuelve la Primera Respuesta de la Pregunta.
 ********************************************************************/
pregunta::respuesta pregunta::getRespuestaA(){
    
}

/*********************************************************************
 *  Devuelve la Segunda Respuesta de la Pregunta.
 ********************************************************************/
pregunta::respuesta pregunta::getRespuestaB(){
    
}

/*********************************************************************
 *  Devuelve la Tercera Respuesta de la Pregunta.
 ********************************************************************/
pregunta::respuesta pregunta::getRespuestaC(){
    
}

/*********************************************************************
 *  Devuelve la Cuarta Respuesta de la Pregunta.
 ********************************************************************/
pregunta::respuesta pregunta::getRespuestaD(){
    
}

/*********************************************************************
 *  Devuelve la letra de la Respuesta correcta de la Pregunta.
 ********************************************************************/
char pregunta::getRespuestaCorrecta(){
    
}

/*********************************************************************
 *  Muestra por pantalla la Pregunta formateada.
 ********************************************************************/
string pregunta::mostrar(){
    
}